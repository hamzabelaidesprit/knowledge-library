<?php
require_once '../includes/auth.php';
redirectIfNotLoggedIn();

if (!isset($_GET['file'])) {
    die("Invalid request.");
}

$filename = basename($_GET['file']);
$filepath = "../uploads/" . $filename;

if (!file_exists($filepath)) {
    die("File not found.");
}

// Optional: force download instead of view
header("Content-Type: application/pdf");
header("Content-Disposition: inline; filename=\"$filename\"");
readfile($filepath);
exit;
