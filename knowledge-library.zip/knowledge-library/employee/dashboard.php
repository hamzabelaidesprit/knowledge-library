<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
redirectIfNotLoggedIn();

$employeeId = $_SESSION['user_id'];
$specialityId = $_SESSION['speciality_id'];

// Fetch PDFs assigned to this employee (speciality or direct)
$stmt = $pdo->prepare("
    SELECT DISTINCT pdf_files.*
    FROM pdf_files
    LEFT JOIN employee_files ON pdf_files.id = employee_files.file_id
    WHERE 
        pdf_files.assigned_speciality_id = :speciality_id
        OR employee_files.employee_id = :employee_id
    ORDER BY upload_date DESC
");
$stmt->execute([
    ':speciality_id' => $specialityId,
    ':employee_id' => $employeeId
]);

$files = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Documents | Knowledge Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?></h3>
    <p class="text-muted">Below are your assigned documents.</p>

    <table class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>Title</th>
                <th>Uploaded On</th>
                <th>File</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($files)): ?>
                <?php foreach ($files as $file): ?>
                    <tr>
                        <td><?= htmlspecialchars($file['title']) ?></td>
                        <td><?= $file['upload_date'] ?></td>
                        <td><a href="view.php?file=<?= $file['filename'] ?>" class="btn btn-sm btn-primary" target="_blank">View / Download</a></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="3">No documents assigned to you yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="../logout.php" class="btn btn-outline-danger">Logout</a>
</div>
</body>
</html>
