<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

// Handle speciality update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['employee_id'], $_POST['speciality_id'])) {
    $stmt = $pdo->prepare("UPDATE employees SET speciality_id = ? WHERE id = ?");
    $stmt->execute([$_POST['speciality_id'], $_POST['employee_id']]);
    header("Location: manage_employees.php?updated=1");
    exit;
}

// Optional: Delete employee
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM employee_files WHERE employee_id = ?")->execute([$id]);
    $pdo->prepare("DELETE FROM employees WHERE id = ?")->execute([$id]);
    header("Location: manage_employees.php?deleted=1");
    exit;
}

// Load data
$employees = $pdo->query("SELECT * FROM employees WHERE is_admin = 0")->fetchAll(PDO::FETCH_ASSOC);
$specialities = $pdo->query("SELECT * FROM specialities")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Employees | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Manage Employees</h3>

    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success">Speciality updated successfully.</div>
    <?php elseif (isset($_GET['deleted'])): ?>
        <div class="alert alert-warning">Employee deleted.</div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Speciality</th>
                <th>Change Speciality</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($employees)): ?>
                <?php foreach ($employees as $emp): ?>
                    <tr>
                        <td><?= htmlspecialchars($emp['name']) ?></td>
                        <td><?= htmlspecialchars($emp['email']) ?></td>
                        <td>
                            <?php
                            $current = array_filter($specialities, fn($s) => $s['id'] == $emp['speciality_id']);
                            echo $current ? htmlspecialchars(array_values($current)[0]['name']) : '—';
                            ?>
                        </td>
                        <td>
                            <form method="POST" class="d-flex">
                                <input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
                                <select name="speciality_id" class="form-select form-select-sm me-2" required>
                                    <option value="">-- Select --</option>
                                    <?php foreach ($specialities as $spec): ?>
                                        <option value="<?= $spec['id'] ?>" <?= $spec['id'] == $emp['speciality_id'] ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($spec['name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                            </form>
                        </td>
                        <td>
                            <a href="?delete=<?= $emp['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this employee?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5">No employees found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</div>
</body>
</html>
