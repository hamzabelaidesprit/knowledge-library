<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

// Delete file if requested
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $fileId = (int)$_GET['delete'];

    // Get the filename
    $stmt = $pdo->prepare("SELECT filename FROM pdf_files WHERE id = ?");
    $stmt->execute([$fileId]);
    $file = $stmt->fetch();

    if ($file) {
        // Delete file from folder
        $filePath = "../uploads/" . $file['filename'];
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete from DB
        $pdo->prepare("DELETE FROM employee_files WHERE file_id = ?")->execute([$fileId]);
        $pdo->prepare("DELETE FROM pdf_files WHERE id = ?")->execute([$fileId]);

        header("Location: manage_files.php?deleted=1");
        exit;
    }
}

$files = $pdo->query("
    SELECT pdf_files.*, specialities.name AS speciality_name
    FROM pdf_files
    LEFT JOIN specialities ON pdf_files.assigned_speciality_id = specialities.id
    ORDER BY upload_date DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Files | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Manage Uploaded Files</h3>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success">File deleted successfully.</div>
    <?php endif; ?>

    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>File</th>
                <th>Assigned to Speciality</th>
                <th>Uploaded</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($files) > 0): ?>
                <?php foreach ($files as $file): ?>
                    <tr>
                        <td><?= htmlspecialchars($file['title']) ?></td>
                        <td><a href="../uploads/<?= $file['filename'] ?>" target="_blank">View</a></td>
                        <td><?= $file['speciality_name'] ?? '—' ?></td>
                        <td><?= $file['upload_date'] ?></td>
                        <td>
                            <a href="?delete=<?= $file['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this file?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="5">No files uploaded yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</div>
</body>
</html>
