<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

$specialities = $pdo->query("SELECT * FROM specialities")->fetchAll(PDO::FETCH_ASSOC);
$employees = $pdo->query("SELECT id, name FROM employees WHERE is_admin = 0")->fetchAll(PDO::FETCH_ASSOC);
$uploadSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $speciality_id = $_POST['speciality_id'] ?? null;
    $selected_employees = $_POST['employee_ids'] ?? [];

    if (isset($_FILES['pdf_file']) && $_FILES['pdf_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['pdf_file']['tmp_name'];
        $file_name = time() . "_" . basename($_FILES['pdf_file']['name']);
        $destination = "../uploads/" . $file_name;

        if (move_uploaded_file($file_tmp, $destination)) {
            // Save to pdf_files table
            $stmt = $pdo->prepare("INSERT INTO pdf_files (title, filename, assigned_speciality_id) VALUES (?, ?, ?)");
            $stmt->execute([$title, $file_name, $speciality_id ?: null]);
            $file_id = $pdo->lastInsertId();

            // Assign to specific employees (if selected)
            foreach ($selected_employees as $emp_id) {
                $pdo->prepare("INSERT INTO employee_files (employee_id, file_id) VALUES (?, ?)")
                    ->execute([$emp_id, $file_id]);
            }

            $uploadSuccess = true;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload PDF | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Upload a PDF Document</h3>

    <?php if ($uploadSuccess): ?>
        <div class="alert alert-success">File uploaded successfully.</div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Select PDF File</label>
            <input type="file" name="pdf_file" class="form-control" accept="application/pdf" required>
        </div>

        <div class="mb-3">
            <label>Assign to Speciality (optional)</label>
            <select name="speciality_id" class="form-select">
                <option value="">-- None --</option>
                <?php foreach ($specialities as $spec): ?>
                    <option value="<?= $spec['id'] ?>"><?= htmlspecialchars($spec['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Assign to Specific Employees (optional)</label>
            <?php foreach ($employees as $emp): ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="employee_ids[]" value="<?= $emp['id'] ?>" id="emp<?= $emp['id'] ?>">
                    <label class="form-check-label" for="emp<?= $emp['id'] ?>">
                        <?= htmlspecialchars($emp['name']) ?>
                    </label>
                </div>
            <?php endforeach; ?>
        </div>

        <button type="submit" class="btn btn-primary">Upload</button>
        <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </form>
</div>
</body>
</html>
