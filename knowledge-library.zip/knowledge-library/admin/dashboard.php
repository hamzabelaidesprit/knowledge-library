<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard | Knowledge Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-4">
        <h2 class="mb-4">Welcome, Admin <?= htmlspecialchars($_SESSION['user_name']) ?></h2>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Upload PDF</h5>
                        <p class="card-text">Upload and assign documents to specialities or individuals.</p>
                        <a href="upload.php" class="btn btn-primary w-100">Go to Upload</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Manage Employees</h5>
                        <p class="card-text">Add or remove employees, change roles or specialties.</p>
                        <a href="manage_employees.php" class="btn btn-secondary w-100">Manage Employees</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title">Manage Files</h5>
                        <p class="card-text">View, delete, or reassign uploaded documents.</p>
                        <a href="manage_files.php" class="btn btn-success w-100">Manage Files</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <a href="../logout.php" class="btn btn-outline-danger">Logout</a>
        </div>
    </div>
</body>
</html>
