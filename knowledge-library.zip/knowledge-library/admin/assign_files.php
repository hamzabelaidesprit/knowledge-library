<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

// Load data
$files = $pdo->query("SELECT * FROM pdf_files ORDER BY upload_date DESC")->fetchAll(PDO::FETCH_ASSOC);
$employees = $pdo->query("SELECT id, name FROM employees WHERE is_admin = 0")->fetchAll(PDO::FETCH_ASSOC);
$specialities = $pdo->query("SELECT * FROM specialities")->fetchAll(PDO::FETCH_ASSOC);

// Handle assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['file_id'])) {
    $file_id = $_POST['file_id'];

    // Update speciality assignment
    if (isset($_POST['speciality_id']) && $_POST['speciality_id']) {
        $stmt = $pdo->prepare("UPDATE pdf_files SET assigned_speciality_id = ? WHERE id = ?");
        $stmt->execute([$_POST['speciality_id'], $file_id]);
    }

    // Assign selected employees
    if (isset($_POST['employee_ids'])) {
        foreach ($_POST['employee_ids'] as $emp_id) {
            // Prevent duplicates
            $check = $pdo->prepare("SELECT * FROM employee_files WHERE employee_id = ? AND file_id = ?");
            $check->execute([$emp_id, $file_id]);
            if (!$check->fetch()) {
                $stmt = $pdo->prepare("INSERT INTO employee_files (employee_id, file_id) VALUES (?, ?)");
                $stmt->execute([$emp_id, $file_id]);
            }
        }
    }

    header("Location: assign_files.php?assigned=1");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Files | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h3>Assign Files to Employees or Specialities</h3>

    <?php if (isset($_GET['assigned'])): ?>
        <div class="alert alert-success">File assignments updated successfully.</div>
    <?php endif; ?>

    <?php if ($files): ?>
        <form method="POST">
            <div class="mb-3">
                <label>Select File</label>
                <select name="file_id" class="form-select" required>
                    <option value="">-- Select File --</option>
                    <?php foreach ($files as $file): ?>
                        <option value="<?= $file['id'] ?>"><?= htmlspecialchars($file['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Assign to Speciality</label>
                <select name="speciality_id" class="form-select">
                    <option value="">-- None --</option>
                    <?php foreach ($specialities as $spec): ?>
                        <option value="<?= $spec['id'] ?>"><?= htmlspecialchars($spec['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Assign to Specific Employees</label>
                <?php foreach ($employees as $emp): ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="employee_ids[]" value="<?= $emp['id'] ?>" id="emp<?= $emp['id'] ?>">
                        <label class="form-check-label" for="emp<?= $emp['id'] ?>">
                            <?= htmlspecialchars($emp['name']) ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="submit" class="btn btn-primary">Assign File</button>
            <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
        </form>
    <?php else: ?>
        <div class="alert alert-info">No files uploaded yet. <a href="upload.php">Upload now</a>.</div>
    <?php endif; ?>
</div>
</body>
</html>
