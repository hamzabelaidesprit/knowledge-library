<?php
$host = "localhost";
$user = "seeka607_knowledge-library";
$pass = "Ets123@333"; // Change if you use a password
$dbname = "seeka607_knowledge-library";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
